# Remember What We're Teaching.md
SUDO PASSWORD: Antony£)


When Creating the Course Pages, Remember What We're Teaching, and what the Back End Needs to Look like. Back end Preferably Written in GoLang, not Python

## Guidelines

**Programs we'll be Teaching**
Python for Offensive Security
C & Assembly: The Exploit Developer's Core
JavaScript & Browser Exploitation
SQL & Database Exploitation
Reverse Engineering for Exploit Development
Rootkit Development - The Art of Staying Hidden

**Back End**

Must be Written in GoLang
