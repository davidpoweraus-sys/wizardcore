import LearningEnvironment from '@/components/learning/LearningEnvironment'

export default function LearningPage() {
  return (
    <div className="h-screen">
      <LearningEnvironment />
    </div>
  )
}